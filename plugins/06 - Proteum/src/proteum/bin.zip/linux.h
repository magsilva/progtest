#define __signed__	signed
#define __const		const
#define __asm__(x)
#define __inline__	
#define __attribute__(x)
#define __extension__ 
#define __restrict 

#ifndef __builtin_va_list
#	define __builtin_va_list 
#endif


